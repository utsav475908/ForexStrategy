//
//  OrderBlockRating.swift
//  ForexStrategy
//
//  Created by kumar utsav on 24/10/24.
//

import SwiftUI

struct OrderBlockRatingView: View {

    var body: some View {
        if let pdfURL = Bundle.main.url(forResource: StrategyPDF.OrderBlockRating, withExtension: "pdf") {
            PDFKitView(url: pdfURL) // Use the PDFKitView to display the PDF
                .edgesIgnoringSafeArea(.all) // Fullscreen for PDF viewing
        } else {
            Text("PDF not found")
        }
    }
}

struct OrderBlockRatingView_Previews: PreviewProvider {
    static var previews: some View {
        OrderBlockRatingView()
    }
}
