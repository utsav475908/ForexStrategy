import SwiftUI
import PDFKit

enum Strategy {
    case Mulham
    case Fractal
    case OrderBlockRating
    case CasperSMC
}

struct StrategyPDF {
    static let Mulham = "Mulham"
    static let Fractal = "Fractal"
    static let OrderBlockRating = "OrderBlockRating"
    static let CasperSMC = "CasperSMC"
}



// Step 1: PDFKitView to wrap PDFView (from PDFKit) in SwiftUI
struct PDFKitView: UIViewRepresentable {
    var url: URL

    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.document = PDFDocument(url: url) // Load PDF from the provided URL
        pdfView.autoScales = true // Automatically scale the PDF to fit the view
        return pdfView
    }

    func updateUIView(_ pdfView: PDFView, context: Context) {
        // Nothing to update here since PDFView doesn't change dynamically
    }
}

struct ContentView: View {
    var body: some View {
        TabView {
            MulhamStrategyView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Mulham")
                }

            FractalStrategyView()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Fractal")
                }

            // Settings tab displaying the PDF using PDFKit
            OrderBlockRatingView()
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("OrderBlock")
                }
            
            CasperSMCView()
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("CasperSMC")
                }
        }
    }
}

// Placeholder views for Home and Search tabs
struct HomeView: View {
    var body: some View {
        Text("Home Tab")
            .font(.largeTitle)
            .padding()
    }
}

struct SearchView: View {
    var body: some View {
        Text("Search Tab")
            .font(.largeTitle)
            .padding()
    }
}

// App Entry Point
@main
struct MyTabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

